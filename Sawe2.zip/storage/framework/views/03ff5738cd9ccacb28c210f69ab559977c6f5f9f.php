<?php $__env->startSection('content'); ?>
<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Name</th>
      <th scope="col">Role</th>
      <th scope="col">Email</th>
      <th scope="col">Phone number</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr id="<?php echo e($user->id); ?>">
      <th scope="row"><?php echo e($user->id); ?></th>
      <td><?php echo e($user->name); ?></td>
      <td><?php echo e($user->user_role); ?></td>
      <td><?php echo e($user->email); ?></td>
      <td><?php echo e($user->phone); ?></td>
      <td><button type="button" class="btn btn-warning"><a href="/updateForm/<?php echo e($user->id); ?>">Update</a></button>
        <form method="POST" action="/userDelete/<?php echo e($user->id); ?>">
            <?php echo csrf_field(); ?>
            <button class="btn btn-primary">Delete</button>
          </form>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OATech\OneDrive\Documents\projects\Sawe2\Sawe2Wtsawa2\resources\views/admin/users_admin.blade.php ENDPATH**/ ?>