<?php $__env->startSection('app'); ?>

<section class="products">

    <h1 class="heading"><span>Product</span> </h1>
    <div class="box-container">
        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="box">
            <div class="image">
                <img src="<?php echo e(asset('../image/'.$tea->image_path)); ?>" alt="">
            </div>
            <div class="content">
                <h3><?php echo e($prod->name); ?></h3>
                <div class="price"><?php echo e($prod->description); ?></div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OATech\OneDrive\Documents\projects\Sawe2\Sawe2Wtsawa2\resources\views/TeamOneProduct.blade.php ENDPATH**/ ?>