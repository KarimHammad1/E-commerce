<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- swiper css link  -->
    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />


    <!-- cusom css file link  -->
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async=""></script>

</head>
<body>

<!-- header section starts  -->

<header class="header">

    <a href="/" class="logo"> <i class="fas fa-store"></i> Sawe2 W Tsawa2 </a>


    

    <div class="icons">
        <div id="menu-btn" class="fas fa-bars"></div>
        <div id="search-btn" class="fas fa-search"></div>

<?php if(Auth::guest()): ?>
        <a href="/login" class="fas fa-user"></a>
 <?php endif; ?>
    </div>


</header>

<!-- header section ends -->

<!-- side-bar section starts -->

<div class="side-bar">
<?php if(Auth::user()): ?>
    <div id="close-side-bar" class="fas fa-times"></div>
<a href="/profile">
    <div class="user">
        <img src="<?php echo e(asset('../image/'.auth::user()->image_path)); ?>" alt="">
        <h3><?php echo e(auth::user()->name); ?></h3>
        <a href="/logout">log out</a>
    </div>
</a>
<?php endif; ?>
    <nav class="navbar">
        <a href="/"> <i class="fas fa-angle-right"></i> home </a>
        <a href="/team"> <i class="fas fa-angle-right"></i> Team </a>
        <a href="/about"> <i class="fas fa-angle-right"></i> about </a>
        <?php if(Auth::user()): ?>
        
        <a href="/MyProducts"> <i class="fas fa-angle-right"></i>My Product</a>

        <?php endif; ?>
        <a href="/catprod"> <i class="fas fa-angle-right"></i> products </a>
        

<?php if(Auth::guest()): ?>
        <a href="/login"> <i class="fas fa-angle-right"></i> login </a>
        <?php endif; ?>
    </nav>

</div>


<!-- side-bar section ends -->
<?php echo $__env->yieldContent('app'); ?>
<!-- footer section starts  -->

<section class="quick-links">

    <a href="/" class="logo"> <i class="fas fa-store"></i> Sawe2 W Tsawa2 </a>

    <div class="links">
        <a href="/"> home </a>
        <a href="/team"> Team </a>
        <a href="/about"> about </a>
        <a href="/catprod"> products </a>
        
        <?php if(Auth::user()): ?>
        <a href="/MyProducts">My Product</a>
        <?php endif; ?>
        <a href="/login"> login </a>

    </div>

    <div class="share">
        <a href="https://wa.me/0096176544784" class="fab fa-whatsapp"></a>
    </div>

</section>

<section class="credit">

    <p> created by <span><a href="https://www.nolimitsdevs.com/">NoLimits</a></span> | all rights reserved! </p>


</section>

<!-- footer section ends -->




<!-- swiper js link      -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="../js/script.js"></script>


</body>
</html>
<?php /**PATH C:\Users\OATech\OneDrive\Documents\projects\Sawe2\Sawe2Wtsawa2\resources\views/Layout/app.blade.php ENDPATH**/ ?>