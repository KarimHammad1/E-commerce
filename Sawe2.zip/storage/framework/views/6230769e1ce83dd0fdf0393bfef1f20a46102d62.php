<?php $__env->startSection('content'); ?>

<form method="POST" action="/admin/updateOffer/<?php echo e($offer->id); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row"  >
        <div class="col-sm-2">
        <label for="" class="form-label">ProductName</label>
        <input class="form-control" list="datalistOptions" name="name" value="<?php echo e($offer->ProductName); ?>" id="name" placeholder="ProductName">
        </div>
        <div class="col-sm-2">
        <label for=" " class="form-label">UserName</label>
        <input class="form-control" list="datalistOptions" name="userName" value="<?php echo e($offer->userName); ?>" id="email" placeholder="UserName">
        </div>
        <div class="col-sm-2">
        <label for=" " class="form-label">% of discount</label>
        <input class="form-control" list="datalistOptions" name ="discount"  id="" placeholder="% of discount">
        </div>
        <div class="col-sm-2">
        <label for=" " class="form-label">FirstPrice</label>
        <input class="form-control" list="datalistOptions" name ="Fprice" value="<?php echo e($offer->FirstPrice); ?>" id="address" placeholder="Fprice">
        </div>
        <div class="col-sm-2">
            <label for=" " class="form-label">LastPrice</label>
            <input class="form-control" list="datalistOptions" name ="LastPrice" value="<?php echo e($offer->Lastprice); ?>" id="address" placeholder="Lprice">
            </div>
        <div class="col-sm-3">
        <label for=" " class="form-label">Image</label>
        <input type="file" class="form-control" value="<?php echo e($offer->image_path); ?>" name="Image">
        </div>
      </div>
      <div class="row"  >
        <div class="col-sm-2">
        <label for="" class="form-label">Description</label>
        <input type="text" class="form-control" list="datalistOptions" value="<?php echo e($offer->description); ?>" name="description" id="password" placeholder="Description">
        </div>
      </div>
     <div class="row">
     <div class="col-sm-3">&nbsp</div>
     <div class="col-sm-2"></div>
     <div class="col-sm-3">
     <input type="submit" value="Update Offer" class="btn btn-primary">
     </div>
     </div>
    </form>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OATech\OneDrive\Documents\projects\Sawe2\Sawe2Wtsawa2\resources\views/admin/updateOffer.blade.php ENDPATH**/ ?>