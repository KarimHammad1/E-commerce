<?php $__env->startSection('content'); ?>

<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Name</th>
      <th scope="col">User_id</th>
      <th scope="col">Category_id</th>
      <th scope="col">Price</th>
      <th scope="col" style="width:300px;">Description</th>
      <th scope="col">Image</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr id="<?php echo e($prod->id); ?>">
      <th scope="row"><?php echo e($prod->id); ?></th>
      <td><?php echo e($prod->name); ?></td>
      <td><?php echo e($prod->user_id); ?></td>
      <td><?php echo e($prod->catg_id); ?></td>
      <td><?php echo e($prod->price); ?></td>
      <td><?php echo e($prod->description); ?></td>
      <td><?php echo e($prod->image_path); ?></td>
      <td>
        <a href="/update_product/<?php echo e($prod->id); ?>"><button type="button" class="btn btn-warning">Update</button></a>
        <a href="/delete_prod/<?php echo e($prod->id); ?>"><button type="button" class="btn btn-danger">Delete</button></a>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OATech\OneDrive\Documents\projects\Sawe2\Sawe2Wtsawa2\resources\views/admin/products.blade.php ENDPATH**/ ?>