<?php $__env->startSection('app'); ?>

<!-- home section starts  -->
<section class="home">

    <div class="swiper home-slider">



        <div class="swiper-wrapper">
        <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="swiper-slide slide">

            <div class="image">
                <img src="<?php echo e(asset('../image/'.$ban->image_path)); ?>" alt="">
            </div>
            <div class="content">
                <span>Last Price : <?php echo e($ban->Lastprice); ?></span>
                <h3><?php echo e($ban->ProductName); ?></h3>
                <h4><?php echo e($ban->description); ?></h4>
                <a href="https://wa.me/<?php echo e($ban->userPhone); ?>?text=Hello I saw <?php echo e($ban->ProductName); ?>

                    at Sawe2 w Tsawa2 with last price : <?php echo e($ban->Lastprice); ?> please give me more Details" class="btn">shop now</a>
            </div>


        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>

    </div>


</section>

<!-- home section ends -->

<!-- banner section starts  -->

<section class="banner">

    <div class="box-container">

        <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="#" class="box">
            <img src="<?php echo e(asset('../image/'.$offer->image_path)); ?>" alt="">
            <div class="content">
                <span><?php echo e($offer->ProductName); ?></span>
                <h3><?php echo e($offer->description); ?></h3>
                <h3>Last Price: <?php echo e($offer->Lastprice); ?></h3>
            </div>

        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</section>

<!-- banner section ends -->

<!-- arrivals section starts  -->

<?php $__env->stopSection(); ?>
<!-- arrivals section ends -->

<?php echo $__env->make('Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OATech\OneDrive\Documents\projects\Sawe2\Sawe2Wtsawa2\resources\views/home.blade.php ENDPATH**/ ?>