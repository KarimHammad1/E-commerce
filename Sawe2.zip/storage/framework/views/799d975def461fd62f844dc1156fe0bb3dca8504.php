<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <title>Add Product</title>
</head>
<body>
    <div class="container" style="margin-top: 20px">
    <form method="POST" action="/updateProd/<?php echo e($product->id); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="container">
            <div class="row row-cols-3">
                    <div class="col">
                      <label for="inputEmail4">Name of product</label>
                      <input type="text" name="name" value="<?php echo e($product->name); ?>" class="form-control" id="inputEmail4" placeholder="name of product">
                    </div>
                    <div class="col">
                      <label for="inputPassword4">Description</label>
                      <input type="text" name="description" value="<?php echo e($product->description); ?>" class="form-control" id="inputPassword4" placeholder="description">
                    </div>
                    <div class="col">
                      <label for="inputCity">Price</label>
                      <input type="text" name="price" value="<?php echo e($product->price); ?>" class="form-control" id="inputCity">
                    </div>
                    <div class="col">
                      <label for="inputState">Category</label>
                      <select id="inputState" name="category"  class="form-control">
                        <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                      <div class="col">
                        <label for="inputCity">Image</label>
                        <input type="file" name="image" class="form-control" id="inputCity">
                      </div>
                  </div>
                  <button style="margin-top: 10px" type="submit" class="btn btn-primary">Update Product</button>
                </form>
              </div>
            </div>

            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
</body>
</html>
<?php /**PATH C:\Users\OATech\OneDrive\Documents\projects\Sawe2\Sawe2Wtsawa2\resources\views/User/updateProduct.blade.php ENDPATH**/ ?>