<?php $__env->startSection('app'); ?>

<section class="products">
    <?php $__currentLoopData = $userName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h1 class="heading"><?php echo e($name->name); ?>'s  <span>Product</span> </h1>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="box-container">
        <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="box">
            <div class="image">
                <img src="<?php echo e(asset('../image/'.$tea->image_path)); ?>" alt="">
            </div>
            <div class="content">
                <h3><?php echo e($tea->name); ?></h3>
                <div class="price"><?php echo e($tea->description); ?></div>
                <?php $__currentLoopData = $userPhone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="https://wa.me/<?php echo e($phone->phone); ?>" style="font-size: 24px" class="fab fa-whatsapp"> Text for more details</a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>


</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OATech\OneDrive\Documents\projects\Sawe2\Sawe2Wtsawa2\resources\views/TeamProduct.blade.php ENDPATH**/ ?>