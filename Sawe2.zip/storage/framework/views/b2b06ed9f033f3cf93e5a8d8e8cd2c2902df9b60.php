<?php $__env->startSection('content'); ?>

<form method="POST" action="/admin/catUpdate/<?php echo e($cat->id); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row"  >
        <div class="col-sm-2">
        <label for="" class="form-label">Name</label>
        <input class="form-control" list="datalistOptions" value="<?php echo e($cat->name); ?>" name="name" id="name" placeholder="Name">
        </div>
        <div class="col-sm-3">
        <label for=" " class="form-label">Image</label>
        <input type="file" class="form-control" <?php echo e($cat->image_path); ?> name="Image">
        </div>
      </div>
      <div class="row"  >
      </div>
     <div class="row">
     <div class="col-sm-3">&nbsp</div>
     <div class="col-sm-2"></div>
     <div class="col-sm-3">
     <input type="submit" value="Update Catogry" class="btn btn-primary">
     </div>
     </div>
    </form>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OATech\OneDrive\Documents\projects\Sawe2\Sawe2Wtsawa2\resources\views/admin/catUpdate.blade.php ENDPATH**/ ?>