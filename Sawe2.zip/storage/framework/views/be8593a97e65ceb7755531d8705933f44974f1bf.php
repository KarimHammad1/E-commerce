<?php $__env->startSection('app'); ?>
<h1 class="heading"><span>products</span> </h1>


<section class="products">
    <a href="/addProductForm" class="btn">Add Product</a>
    <div class="box-container">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="box">
            <div class="image">

                <img src="<?php echo e(asset('../image/'.$product->image_path)); ?>" alt="">
            </div>
            <div class="content">
                <h3><?php echo e($product->name); ?></h3>
                <h4><?php echo e($product->description); ?></h4>
                <div class="price"><?php echo e($product->price); ?></div>
                <a href="/userUpdateproduct/<?php echo e($product->id); ?>" class="btn">Update</a>
                <a style="margin-left: 20px" href="/deleteProduct/<?php echo e($product->id); ?>" class="btn">Delete</a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OATech\OneDrive\Documents\projects\Sawe2\Sawe2Wtsawa2\resources\views/User/viewProduct.blade.php ENDPATH**/ ?>