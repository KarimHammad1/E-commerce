<?php $__env->startSection('app'); ?>


<!-- products section starts  -->


<section class="products">
    <h1 class="heading"> featured <span>products</span> </h1>
    <div class="box-container">

        <div class="box">
            <div class="image">
                <img src="<?php echo e(asset('../image/'.$product->image_path)); ?>" alt="">
            </div>
            <div class="content">
                <h3><?php echo e($product->name); ?></h3>
                <div class="price"><?php echo e($product->price); ?></div>
            </div>
        </div>


    </div>

</section>



<?php $__env->stopSection(); ?>
<!-- product banner section ends -->



<?php echo $__env->make('Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OATech\OneDrive\Documents\projects\Sawe2\Sawe2Wtsawa2\resources\views/User/singleProduct.blade.php ENDPATH**/ ?>