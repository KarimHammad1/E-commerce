<?php $__env->startSection('content'); ?>

<form method="POST" action="/addcategory" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row"  >
        <div class="col-sm-2">
        <label for="" class="form-label">Name</label>
        <input class="form-control" list="datalistOptions" name="name" id="name" placeholder="Name">
        </div>
        <div class="col-sm-3">
        <label for=" " class="form-label">Image</label>
        <input type="file" class="form-control" name="Image">
        </div>
      </div>
      <div class="row"  >
      </div>
     <div class="row">
     <div class="col-sm-3">&nbsp</div>
     <div class="col-sm-2"></div>
     <div class="col-sm-3">
     <input type="submit" value="Add Catogry" class="btn btn-primary">
     </div>
     </div>
    </form>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<table class="table">

    <thead class="thead-dark">
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Name</th>
        <th scope="col">Image_Path</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr id="<?php echo e($cat->id); ?>">
        <th scope="row"><?php echo e($cat->id); ?></th>
        <td><?php echo e($cat->name); ?></td>
        <td><?php echo e($cat->image_path); ?></td>
        <td><button type="button" class="btn btn-warning"><a href="/catUpdate/<?php echo e($cat->id); ?>">Update</a></button>
            <form method="POST" action="/categoryDelete/<?php echo e($cat->id); ?>">
                <?php echo csrf_field(); ?>
                <button class="btn btn-primary">Delete</button>
              </form>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OATech\OneDrive\Documents\projects\Sawe2\Sawe2Wtsawa2\resources\views/admin/catogry.blade.php ENDPATH**/ ?>