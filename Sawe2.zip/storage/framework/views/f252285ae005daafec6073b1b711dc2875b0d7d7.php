<?php $__env->startSection('app'); ?>

<!-- about section starts  -->

<section class="about">

    <div class="image">
        <img src="images/about-img.png" alt="">
    </div>

    <div class="content">
        <h3>our story</h3>
        <p>Have you ever been through meaningless and unwanted stories
            and ads on your social media
            and couldn't find what you are looking for we all have been there
            right!! </p>
        <p> So, we decided to make your lives easier by
            creating this website where you can find everything
            you want and at competitive prices
            and the best part is not only
            you can buy. you can offer your
            own products where many can see it!!</p>

    </div>

</section>
<?php $__env->stopSection(); ?>
<!-- about section ends -->





<?php echo $__env->make('Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OATech\OneDrive\Documents\projects\Sawe2\Sawe2Wtsawa2\resources\views/About.blade.php ENDPATH**/ ?>